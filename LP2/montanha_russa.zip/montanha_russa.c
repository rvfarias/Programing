#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <pthread.h>

#define NUM_PESSOAS 20

int num_voltas;																								//Variavel que armazena o numero de voltas
int num_pessoas;																							//Variavel que armazena o numero de pessoas em uma volta
//Variaveis auxiliares
int turn[NUM_PESSOAS];
int next = 1;
int number = 1;
int ne = 1;
int nu = 1;

//Variaveis de controle da montanha russa
int go = 1;
int stop = 0;


//Fução a ser chamada pelas threads pessoas
void* func_pessoa(void* p) {

	long n = (long) p;

	//Enquanto o parque estiver aberto
	while(num_voltas < 10) {

			turn[n] = __sync_fetch_and_add(&number, 1);
			//Protocolo de controle de entrada na montanha russa
			//Entra apenas 5 caso o carro esteja parado
			while(turn[n] != next || num_pessoas >= 5 || !(stop));
			printf("Pessoa #%ld - entrou no carro\n", n+1);
	    num_pessoas++;
			next++;

			//Enquanto o carro estiver em movimento
			while (go);
			printf("Pessoa #%ld - saiu do carro\n", n+1);

			//Protocolo de controle de saida na montanha russa
			//Saindo um de cada vez
			turn[n] = __sync_fetch_and_add(&nu, 1);
			while(turn[n] != ne);
			num_pessoas--;
			ne++;

			//Volta pelo parque com tempo aleatório entre 0 e 3 segundos
			sleep((rand() % 3));
	}

		//Ao finalizar as dez voltas fecha o parque
		printf("---- Fechou o parque ----\n");
		exit(0);

}

//Fução a ser chamada pela thread carro
void* func_carro() {

	//Enquanto o parque estiver aberto
  while(num_voltas < 10){

		//Printa o numero da volta atual
		printf("Volta #%d\n", num_voltas + 1);
		//Libera a entrada
		stop = 1;
		//Espera entrar
    usleep(20000);
		//Bloqueia entrada
		stop = 0;

		//Volta iniciou e dura tempo aleatório entre 0 e 3 segundos
		printf("---- Volta #%d iniciou ----\n", num_voltas + 1);
		sleep((rand() % 3));

		//Libera a saída
		go = 0;
		//Esperando esvaziar para iniciar outra volta
		printf("Esperando esvaziar...\n");
		while (num_pessoas != 0);
		//Bloqueia saída e incrementa o numero de voltas
		go = 1;
		num_voltas++;

	}

}

int main(void) {

	//Declaração das threads representativas
	pthread_t pessoas[NUM_PESSOAS];
  pthread_t carro;
	//Inicializando variaveis
	num_voltas = 0;
	num_pessoas = 0;
	long i;

  for (i = 0; i < NUM_PESSOAS; i++) {
    turn[i] = 0;
  }

	//Inicializando threads
	printf("---- Parque aberto ----\n");

  pthread_create(&carro, NULL, func_carro, NULL);

	for (i = 0; i < NUM_PESSOAS; i++) {

		pthread_create(&pessoas[i], NULL, func_pessoa, (void*) i);

	}

	//Mantendo o programa até as 10 voltas serem realizadas
  while(1);

  return 0;

}
