thread_creator v1.0

use the Makefile to compile:
make exponential: builds the exponential thread creator
make while: builds the linear thread creator

make all: builds both

the default compiler is clang, if you don't have clang, change the CC macro on the Makefile
