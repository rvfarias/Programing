#include <unistd.h>     /* Symbolic Constants */
#include <sys/types.h>  /* Primitive System Data Types */ 
#include <errno.h>      /* Errors */
#include <stdio.h>      /* Input/Output */
#include <sys/wait.h>   /* Wait for Process Termination */
#include <stdlib.h>     /* General Utilities */
#include <inttypes.h>	/* uintmax_t */
#include <time.h>		/* time() */

uintmax_t max_threads;
uintmax_t max_bit; // biggest 2^n smaller than max_thread
int set_bit; // position of the biggest set bit, from back to front, minus 1
uintmax_t sleep_time = 0;

/* gets the biggest 2^n smaller than
max_thread using __bultin_clzl()*/
void clzl_run()
{
	/*R"eturns the number of leading 0-bits in x,
	starting at the most significant bit position.
	If x is 0, the result is undefined."
	https://gcc.gnu.org/onlinedocs/gcc/Other-Builtins.html */
	set_bit = __builtin_clzl(max_threads);
	size_t max_bits = sizeof(uintmax_t) * 8;
	max_bit = 1;
	max_bit = max_bit << (max_bits - set_bit - 1);
	set_bit = max_bits - set_bit - 1;
}

/* makes threads do things, like printing
some info*/
void do_stuff(uintmax_t id)
{
	printf("#%lu Hello from thread PID %i\n", id, getpid());
	printf("#%lu Unix Time now: %lu\n", id, time(0));
	if (sleep_time > 0)
	{
		printf("#%lu Sleeping for %lu seconds...\n", id, sleep_time);
		sleep(sleep_time);
		printf("#%lu Waked up!\n", id);
	}
	printf("#%lu Exiting now...\n", id);
}

/* creates threads using the
linear method and makes
each run do_stuff(). there's
no guarantee that children will
exit first*/
void create_threads()
{
	clzl_run();
	int i = max_threads - 1;
	// create leading child process
	if (!fork())
	{
		while (i-- && !fork());
		do_stuff(max_threads - i - 2);
		// this or parent exits early
		int status;
		wait(&status);
		exit(0);
	}
	else
	{
		int status;
		wait(&status);
		puts("#Parent: exiting");
	}
}

int main(int argc, char **argv)
{
	if (argc < 2)
	{
		puts("usage: tc_while <number of threads> <time to sleep>");
		puts("\tif <time to sleep> is default to 0");
		return 0;
	}

	max_threads = strtoumax(argv[1], NULL, 0);

	if (max_threads == 0 || (max_threads == UINTMAX_MAX && errno == ERANGE))
	{
		puts("Invalid thread number");
		return 1;
	}
	else if (max_threads > 1000 - 1)
	{
		printf("Alert: you're trying to create %lu threads. Press enter to continue with this madness", max_threads);
		getchar();
	}

	if (argc > 2)
	{
		sleep_time = strtoumax(argv[2], NULL, 0);
		if (sleep_time == UINTMAX_MAX && errno == ERANGE)
		{
			puts("Invalid sleep time");
			return 2;
		}
		else if (sleep_time > 29)
		{
			printf("Alert: you're trying to set spleep time to %lu. Press enter to continue with this boreness", sleep_time);
			getchar();
		}
	}

	create_threads();

	return 0;
}
